import product1 from "./assets/products/1laptop3.jpg";
import product2 from "./assets/products/2.png";
import product3 from "./assets/products/3.png";
import product4 from "./assets/products/4.png";
import product5 from "./assets/products/5.jpg";
import product6 from "./assets/products/6.webp";
import product7 from "./assets/products/7.webp";
import product8 from "./assets/products/8.webp";

export const PRODUCTS = [
  {
    id: 1,
    productName: "ASUS TUF Gaming",
    price: 52990,
    productImage: product1,
  },
  {
    id: 2,
    productName: "Macbook Pro 2022 (M1)",
    price: 105500,
    productImage: product2,
  },
  {
    id: 3,
    productName: "Acer Aspire 5 Gaming Laptop",
    price: 62990,
    productImage: product3,
  },
  {
    id: 4,
    productName: "Acer Predator Helios 300 Gaming Laptop",
    price: 148899,
    productImage: product4,
  },
  {
    id: 5,
    productName: "boAt Rockerz 370",
    price: 999,
    productImage: product5,
  },
  {
    id: 6,
    productName: "JBL T460BT by Harman",
    price: 2499,
    productImage: product6,
  },
  {
    id: 7,
    productName: "Infinity JBL Glide 510",
    price: 1499,
    productImage: product7,
  },
  {
    id: 8,
    productName: "Zebronics Jet PRO Premium Wired Gaming",
    price: 949,
    productImage: product8,
  },
];
