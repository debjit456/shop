import React from "react";
import { PRODUCTS } from "../../products";
import { Product } from "./product";
import "./shop.css";
import img1 from "./banner/9.webp"

export const Shop = () => {
  return (

    <div className="shop">
    
    <div>
        <img className="banner" src= {img1 } alt="./banner/9.webp"/>
      
      </div>
    
    
    
      <div className="shopTitle">
        <h1>Welcome Here!!</h1>
      </div>
        <div className="shopTitle">
        <h3><u>Electronics</u> </h3>
      </div>

      <div className="products">
        {PRODUCTS.map((product) => (
          <Product data={product} />
        ))}
      </div>
    </div>
  );
};
