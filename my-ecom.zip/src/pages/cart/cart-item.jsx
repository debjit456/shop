import React, { useContext } from "react";
import { ShopContext } from "../../context/shop-context";
import { Trash } from "phosphor-react";
import { Minus } from "phosphor-react";
import { Plus } from "phosphor-react";




export const CartItem = (props) => {
  const { id, productName, price, productImage ,} = props.data;
  const { cartItems, addToCart, removeFromCart, deleteFromCart, updateCartItemCount} =
    useContext(ShopContext);

  return (
    <div className="cartbox" >
      <div className="deletesection">
      <button className="delete" onClick={() => deleteFromCart(id)} ><Trash size={20}/> </button> 
      </div>
     
      
      <div className="cartItem">
      <img src={productImage} />
      <div className="description">
        <p>
          <b>{productName}</b>
        </p>
        <p> Price:  ₹{price}</p>
        <div className="countHandler">
          
        <button className="plus" onClick={() => removeFromCart(id)}> <Minus size={15} /> </button>
          <input min="1" max="5" value={cartItems[id]} onChange={(e) => updateCartItemCount(Number(e.target.value), id)}/>
          
          <button className="minus" onClick={() => addToCart(id)}> <Plus size={15} /> </button>  
          
          
         {/* <button onclick={() => deleteFromCart(id)}> t </button>*/}

        </div>
      </div>

      </div>
    
    </div>
  );
};
